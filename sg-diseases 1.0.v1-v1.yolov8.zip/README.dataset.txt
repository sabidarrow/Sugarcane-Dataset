# sg-diseases 1.0 > v1
https://universe.roboflow.com/thesis-tstpo/sg-diseases-1.0

Provided by a Roboflow user
License: CC BY 4.0

